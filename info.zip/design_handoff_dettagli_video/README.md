# Handoff: 07 Dettagli — "Colonna" (video verticale)

> **Prompt per Claude Code:** "Leggi `docs/handoff/dettagli-video/README.md` e implementa la sezione 07 Dettagli come descritto. Rispetta il contratto `data-*` di `docs/ARCHITECTURE.md` §6 e aggiornalo."

## Overview
La sezione 07 (`Details.astro`) passa da foto 21:9 + titolo sotto a una sezione sticky con un **video verticale 9:16**. Il video parte come una finestra piccola al centro e cresce fino a tutta altezza con lo scroll; il titolo è diviso ai due lati del video e si legge riga per riga attraverso di esso.

## About the design files
I file `.dc.html` inclusi sono **riferimenti di design in HTML**, non codice da copiare. Il compito è ricreare il comportamento nel sito Astro esistente, con i suoi pattern: markup in `Details.astro`, effetto nel loop unico (`scroll-fx.ts`, `subscribe`/`onMeasure`, `setStyle`), token di `global.css`, copy in `home.json`.

## Fidelity
**Hi-fi.** Valori, timing e copy sono definitivi.

## Asset
- `dettagli.mp4` (in questo pacchetto) è una **bozza** 4K da 18 MB. Il file finale sarà 1080×1920, 10–12 s, H.264, yuv420p, faststart, senza audio, 2–4 MB.
- Posizione: `public/video/dettagli.mp4` (servito così com'è, niente pipeline immagini). Opzionale: `dettagli.webm` come prima `<source>`.
- `home.details.image` resta: serve al loader intro (`Intro.astro`) e come fallback reduced-motion / errore video.

## Content (`home.json › details`)
Aggiungere, lasciando `title` e `body` come sono:
```json
"video": { "src": "/video/dettagli.mp4" },
"split": [["La maestria", "nei dettagli."], ["*Ogni scelta,*", "*una firma.*"]]
```
`split` = riga × lato (sinistra, destra). Il corsivo `*…*` passa da `rich()` come gli altri titoli. Aggiornare lo schema in `content.config.ts` (`video: z.object({ src: z.string() })`, `split: z.array(z.tuple([z.string(), z.string()]))`).

## Markup (`Details.astro`)
```
section#dettagli.details[data-column]  aria-labelledby="dettagli-title"
└ div.stage                               sticky; top:0; height:100vh; overflow:hidden
  ├ div[data-col-box]                     abs, left/top 50%, translate(-50%,-50%); w = 56vh·9/16; h = 56vh; radius 4px; overflow hidden; bg #1d1b18
  │ ├ video[data-col-video]               autoplay muted loop playsinline preload="auto" aria-hidden; abs inset 0; object-fit cover; scale(1.12)
  │ └ div[data-col-dim]                   abs inset 0; bg rgba(12,11,10,.55); opacity 0
  ├ h2#dettagli-title[data-col-title]     aria-label = titolo completo; font 400 var(--serif); line-height 1; letter-spacing -.01em
  │ └ 4 × span[data-col-w="l1|r1|l2|r2"]  aria-hidden; abs; white-space nowrap; transform translateY(-50%)
  │                                       l* → right: calc(50% + 28vh·9/16 + 40px); r* → left: stesso valore
  │                                       riga 1 top 50%; riga 2 top 56%, opacity 0; riga 2 in var(--gold) corsivo
  ├ span[data-col-foot="n"]               "07"; abs; bottom 64px; opacity 0; 600 12px/1 var(--sans); letter-spacing .2em; color #bdb4a4
  └ p[data-col-foot="p"]                  home.details.body; abs; bottom 64px; opacity 0; body-copy (clamp(15px, .3vw + 13.1px, 22px)/1.65); color #bdb4a4
```
- Altezza sezione: **260vh** desktop, **220vh** sotto 760px.
- Rimuovere dalla sezione `data-clip`, `data-gl`, `data-speed`, `data-zoom` e la regola `.frame { aspect-ratio }`.
- Fallback senza JS / reduced-motion: mostrare lo stato finale (box a tutta altezza, 4 parole e footer visibili).

## Behavior — `scroll-fx.ts › column()`
Nuovo effetto registrato in `initScrollFx()`. Stesso pattern di `zoomReveal()`.

```ts
function column() {
  const sec = $('[data-column]'); if (!sec) return;
  const box = $('[data-col-box]', sec)!, vid = $<HTMLVideoElement>('[data-col-video]', sec)!;
  const dim = $('[data-col-dim]', sec)!, h2 = $('[data-col-title]', sec)!;
  const fn = $('[data-col-foot="n"]', sec)!, fp = $('[data-col-foot="p"]', sec)!;
  const w = { l1: $('[data-col-w="l1"]', sec)!, r1: $('[data-col-w="r1"]', sec)!, l2: $('[data-col-w="l2"]', sec)!, r2: $('[data-col-w="r2"]', sec)! };
  const ease = (t: number) => (t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
  vid.muted = true; vid.play().catch(() => {});
  let b = { top: 0, h: 0 };
  onMeasure(() => { b = { top: docTop(sec), h: sec.offsetHeight }; });
  subscribe((f) => {
    if (!f.changed) return;
    const top = b.top - f.y;
    if (top > f.vh + 50 || top + b.h < -50) return;
    const p = clamp(-top / Math.max(1, b.h - f.vh), 0, 1);
    const e = ease(clamp(p / .55, 0, 1));
    const r2 = clamp((p - .5) / .18, 0, 1), ft = clamp((p - .78) / .12, 0, 1);
    const narrow = f.vw < f.vh * 1.05;
    const bh = f.vh * (.56 + .44 * e);
    const bw0 = Math.min(bh * 9 / 16, f.vw * .72);
    const bw = narrow ? lerp(bw0, f.vw, e) : bh * 9 / 16;
    setStyle(box, 'width', `${bw}px`); setStyle(box, 'height', `${bh}px`);
    setStyle(box, 'border-radius', `${(4 * (1 - e)).toFixed(2)}px`);
    setStyle(vid, 'transform', `scale(${(1.12 - .12 * e).toFixed(4)})`);

    if (narrow) {
      // mobile / portrait: video a schermo pieno, 4 righe centrate sopra, video scurito
      const r1 = clamp((p - .35) / .15, 0, 1);
      setStyle(dim, 'opacity', clamp((p - .3) / .2, 0, 1).toFixed(3));
      setStyle(h2, 'font-size', `${Math.min(64, f.vw * .13)}px`);
      ([['l1', 36, r1], ['r1', 44, r1], ['l2', 56, r2], ['r2', 64, r2]] as const).forEach(([k, t, o]) => {
        const el = w[k];
        setStyle(el, 'left', '50%'); setStyle(el, 'right', 'auto'); setStyle(el, 'top', `${t}%`);
        setStyle(el, 'opacity', o.toFixed(3));
        setStyle(el, 'transform', `translate(-50%, calc(-50% + ${((1 - o) * 24).toFixed(1)}px))`);
      });
      setStyle(fn, 'opacity', '0');
      setStyle(fp, 'left', '20px'); setStyle(fp, 'right', '20px'); setStyle(fp, 'bottom', '40px');
      setStyle(fp, 'max-width', 'none'); setStyle(fp, 'text-align', 'center'); setStyle(fp, 'color', '#e3dccd');
      setStyle(fp, 'opacity', ft.toFixed(3));
      return;
    }

    // desktop: titolo diviso ai lati del video
    setStyle(dim, 'opacity', '0');
    const gap = Math.max(24, f.vw * .028), pad = Math.max(20, f.vw * .04);
    const sideEnd = (f.vw - f.vh * 9 / 16) / 2 - gap - pad;     // spazio laterale a video aperto
    setStyle(h2, 'font-size', `${Math.max(40, Math.min(112, f.vh * .093, sideEnd / 4.8))}px`);
    const edge = `calc(50% + ${(bw / 2 + gap).toFixed(1)}px)`;
    const edgeEnd = `calc(50% + ${(f.vh * 9 / 32 + gap).toFixed(1)}px)`;
    const row1 = `${50 - 6 * r2}%`;
    ([['l1', row1, 1, 0], ['r1', row1, 1, 0], ['l2', '56%', r2, 1], ['r2', '56%', r2, 1]] as const).forEach(([k, t, o, two]) => {
      const el = w[k], left = k[0] === 'l';
      setStyle(el, 'top', t);
      setStyle(el, 'left', left ? 'auto' : edge); setStyle(el, 'right', left ? edge : 'auto');
      setStyle(el, 'opacity', o.toFixed(3));
      setStyle(el, 'transform', `translateY(calc(-50% + ${(two ? (1 - o) * 30 : 0).toFixed(1)}px))`);
    });
    setStyle(fn, 'right', edgeEnd); setStyle(fp, 'left', edgeEnd); setStyle(fp, 'right', 'auto');
    setStyle(fp, 'max-width', `${Math.min(336, sideEnd)}px`); setStyle(fp, 'text-align', 'left'); setStyle(fp, 'color', '#bdb4a4');
    setStyle(fn, 'opacity', ft.toFixed(3)); setStyle(fp, 'opacity', ft.toFixed(3));
  });
}
```

### Timeline (p = progresso nella sezione, 0→1)
| p | Desktop | Mobile |
|---|---|---|
| 0 | box 56vh alto, 9:16, radius 4px; riga 1 ai lati | box 56vh (max 72vw) |
| 0 → .55 | box cresce a 100vh (easeInOutQuad), le parole scorrono coi bordi | box cresce a 100vw × 100vh |
| .30 → .50 | — | video scurito (dim 0 → 1) |
| .35 → .50 | — | riga 1 entra (+24px → 0) |
| .50 → .68 | riga 1 sale 50% → 44%; riga 2 (oro) entra a 56% (+30px → 0) | riga 2 entra |
| .78 → .90 | "07" (sotto a sinistra) e body (sotto a destra) appaiono | body centrato appare |

## Design tokens
- Fondo `#0c0b0a` · box/placeholder `#1d1b18` · testo `#ece5d6` · oro `#c2a36b` (`--gold`) · testo secondario `#bdb4a4` · body su video (mobile) `#e3dccd`
- Serif Instrument Serif (`--serif`) · sans Hanken Grotesk (`--sans`)

## ARCHITECTURE.md da aggiornare
- §6: nuova riga `data-column`, `data-col-box/video/dim/title/w/foot` | Details | `scroll-fx.ts column()` | video 9:16 cresce a tutta altezza, titolo diviso ai lati.
- §6: togliere Details da `data-clip` e `data-gl`.
- §5, riga 07: `sticky 260vh (220vh mobile), video 9:16, [data-column]`.
- `gl/liquid.ts`: Details non ha più `[data-gl]`; controllare che la lista texture non la richieda.

## Files in questo pacchetto
- `Baratto Home v8.dc.html`: pagina completa di riferimento (sezione 07 e metodo `startColumn()`)
- `Baratto Dettagli Opzioni.dc.html`: esplorazioni; quella scelta è la **2a "Colonna"**
- `dettagli.mp4`: video bozza
